import pandas as pd
from pyecharts.charts import Bar, Grid
from pyecharts import options as opts
from pyecharts.commons.utils import JsCode

# 播放量前十的视频
def create_bilibili_fixed_layout(csv_path):
    # 1. 数据读取与处理 (保持不变)
    try:
        try:
            df = pd.read_csv(csv_path, encoding='utf-8')
        except:
            df = pd.read_csv(csv_path, encoding='gb18030')
        df['播放量'] = pd.to_numeric(df['播放量'], errors='coerce').fillna(0).astype(int)
        df_top10 = df.sort_values("播放量", ascending=False).drop_duplicates(subset=["视频BV号"]).head(10)
    except Exception as e:
        print(f"数据处理错误: {e}")
        return

    # 2. 准备数据列表
    titles_short = [str(t)[:12] + "..." if len(str(t)) > 12 else str(t) for t in df_top10["视频标题"]]
    play_counts = [int(v) for v in df_top10["播放量"]]
    up_names = [str(n) for n in df_top10["UP主昵称"]]
    issues = [str(i) for i in df_top10["期数名称"]]
    full_titles = [str(t) for t in df_top10["视频标题"]]

    # 3. 配置柱状图
    bar = (
        Bar()
        .add_xaxis(titles_short)
        .add_yaxis(
            "播放量",
            play_counts,
            color="#FB7299",
            label_opts=opts.LabelOpts(is_show=False)
        )
        .set_global_opts(
            # 标题设置：靠顶端，字体加粗
            title_opts=opts.TitleOpts(
                title="B站每周必看历史 Top 10",
                subtitle="鼠标悬停查看详情",
                pos_top="2%",  # 标题距离顶端 2%
                pos_left="center"
            ),
            # 工具栏配置：如果不需要可以设为 is_show=False
            toolbox_opts=opts.ToolboxOpts(
                is_show=True,
                pos_top="2%",   # 工具按钮也移到顶端
                pos_right="5%"  # 放在右上角，避免挡住中间的标题
            ),
            tooltip_opts=opts.TooltipOpts(
                trigger="axis",
                axis_pointer_type="shadow",
                formatter=JsCode(f"""
                    function (params) {{
                        var idx = params[0].dataIndex;
                        var up_names = {up_names};
                        var issues = {issues};
                        var full_titles = {full_titles};
                        return '<div style="padding:10px; line-height:24px;">' +
                               '<div style="margin-bottom:5px; border-bottom:1px solid #eee;">' +
                               '<b style="color:#FB7299;">' + full_titles[idx] + '</b>' +
                               '</div>' +
                               '👤 <b>UP主：</b>' + up_names[idx] + '<br/>' +
                               '📅 <b>期数：</b>' + issues[idx] + '<br/>' +
                               '🔥 <b>播放总量：</b>' + params[0].value.toLocaleString() + ' 次' +
                               '</div>';
                    }}
                """)
            ),
            xaxis_opts=opts.AxisOpts(axislabel_opts=opts.LabelOpts(rotate=-15)),
            yaxis_opts=opts.AxisOpts(name="播放次数")
        )
    )

    # 4. 使用 Grid 严格控制边距
    grid = (
        Grid(init_opts=opts.InitOpts(width="100%", height="95vh"))
        .add(
            bar,
            grid_opts=opts.GridOpts(
                pos_top="18%",    # ★ 关键：将图表主体下移，给标题和按钮留出 18% 的空间
                pos_bottom="22%", # 给底部旋转后的标题留出空间
                pos_left="10%",
                pos_right="10%"
            )
        )
    )

    grid.render("bilibili_top10.html")
    print("布局已优化！请检查 bilibili_top10.html")

# 播放量前十的up
def create_top_up_chart(csv_path):
    # 1. 加载并聚合数据
    try:
        # 自动处理可能的编码问题
        try:
            df = pd.read_csv(csv_path, encoding='utf-8')
        except:
            df = pd.read_csv(csv_path, encoding='gb18030')

        # 确保播放量列为数值，并按 UP 主聚合求和
        df['播放量'] = pd.to_numeric(df['播放量'], errors='coerce').fillna(0)

        # 核心逻辑：按 UP 主昵称分组，求播放量总和，取前10
        up_rank = df.groupby('UP主昵称')['播放量'].sum().reset_index()
        up_rank = up_rank.sort_values(by='播放量', ascending=False).head(10)

        up_names = up_rank['UP主昵称'].tolist()
        up_views = [int(v) for v in up_rank['播放量']]  # 转为 Python 原生 int 防止报错

    except Exception as e:
        print(f"数据读取或处理失败: {e}")
        return

    # 2. 构建柱状图
    bar = (
        Bar()
        .add_xaxis(up_names)
        .add_yaxis(
            "累计总播放量",
            up_views,
            color="#00AEEC",  # 使用 B 站蓝
            label_opts=opts.LabelOpts(is_show=True, position="top")
        )
        .set_global_opts(
            title_opts=opts.TitleOpts(
                title="B 站每周必看：上榜总播放量最高的 UP 主 Top 10",
                subtitle="统计逻辑：该 UP 主在所有期数中上榜视频的播放量总和",
                pos_top="3%",
                pos_left="center"
            ),
            # 工具栏位置优化，防止重叠
            toolbox_opts=opts.ToolboxOpts(
                is_show=True,
                pos_top="3%",
                pos_right="2%"
            ),
            xaxis_opts=opts.AxisOpts(
                name="UP主",
                axislabel_opts=opts.LabelOpts(rotate=0)
            ),
            yaxis_opts=opts.AxisOpts(
                name="总播放量",
                axislabel_opts=opts.LabelOpts(formatter="{value}")
            ),
            tooltip_opts=opts.TooltipOpts(trigger="axis", axis_pointer_type="shadow")
        )
    )

    # 3. 使用 Grid 解决布局重叠并实现自适应
    grid = (
        Grid(init_opts=opts.InitOpts(width="100%", height="95vh", page_title="UP主战力榜"))
        .add(
            bar,
            grid_opts=opts.GridOpts(
                pos_top="20%",  # 顶部留出 20% 空间给标题和工具栏，彻底解决重叠
                pos_bottom="12%",
                pos_left="10%",
                pos_right="10%"
            )
        )
    )

    # 4. 生成 HTML
    grid.render("bilibili_up_rank.html")
    print("✨ 分析完成！代码已成功执行，请查看生成的 'bilibili_up_rank.html' 文件。")

# 弹幕数前十的视频
def create_top_danmaku_video_chart(csv_path):
    # 1. 加载并清洗数据
    try:
        try:
            df = pd.read_csv(csv_path, encoding='utf-8')
        except:
            df = pd.read_csv(csv_path, encoding='gb18030')

        # 确保弹幕数是数字
        df['弹幕数'] = pd.to_numeric(df['弹幕数'], errors='coerce').fillna(0).astype(int)

        # 按照 BV 号去重，保留该视频在榜单中弹幕最高的一次记录
        df_unique = df.sort_values("弹幕数", ascending=False).drop_duplicates(subset=["视频BV号"]).head(10)

    except Exception as e:
        print(f"数据处理出错: {e}")
        return

    # 2. 准备多维数据（用于 JS 交互提示框）
    titles_short = [str(t)[:12] + "..." if len(str(t)) > 12 else str(t) for t in df_unique["视频标题"]]
    danmaku_counts = [int(v) for v in df_unique["弹幕数"]]
    up_names = [str(n) for n in df_unique["UP主昵称"]]
    issues = [str(i) for i in df_unique["期数名称"]]
    full_titles = [str(t) for t in df_unique["视频标题"]]

    # 3. 配置柱状图
    bar = (
        Bar()
        .add_xaxis(titles_short)
        .add_yaxis(
            "弹幕数",
            danmaku_counts,
            color="#00B5AD",  # 弹幕主题青色
            label_opts=opts.LabelOpts(is_show=False)
        )
        .set_global_opts(
            title_opts=opts.TitleOpts(
                title="B站每周必看：历史弹幕总数最高视频 Top 10",
                subtitle="统计逻辑：单视频弹幕总量排行榜",
                pos_top="3%",
                pos_left="center"
            ),
            # 右上角工具栏，支持下载图片
            toolbox_opts=opts.ToolboxOpts(
                is_show=True,
                pos_top="3%",
                pos_right="2%"
            ),
            # 自定义悬浮框：显示完整标题、UP主及期数
            tooltip_opts=opts.TooltipOpts(
                trigger="axis",
                axis_pointer_type="shadow",
                formatter=JsCode(f"""
                    function (params) {{
                        var idx = params[0].dataIndex;
                        var up_names = {up_names};
                        var issues = {issues};
                        var full_titles = {full_titles};
                        return '<div style="padding:10px; line-height:24px;">' +
                               '<div style="margin-bottom:5px; border-bottom:1px solid #eee;">' +
                               '<b style="color:#00B5AD;">' + full_titles[idx] + '</b>' +
                               '</div>' +
                               '👤 <b>UP主：</b>' + up_names[idx] + '<br/>' +
                               '📅 <b>期数：</b>' + issues[idx] + '<br/>' +
                               '💬 <b>弹幕总量：</b>' + params[0].value.toLocaleString() + ' 条' +
                               '</div>';
                    }}
                """)
            ),
            xaxis_opts=opts.AxisOpts(axislabel_opts=opts.LabelOpts(rotate=-15)),
            yaxis_opts=opts.AxisOpts(name="弹幕数量")
        )
    )

    # 4. 使用 Grid 布局容器实现全屏自适应及边距控制
    grid = (
        Grid(init_opts=opts.InitOpts(width="100%", height="95vh", page_title="弹幕数视频排行"))
        .add(
            bar,
            grid_opts=opts.GridOpts(
                pos_top="18%",  # 预留顶部空间给标题和按钮
                pos_bottom="20%",  # 预留底部空间给旋转的标题
                pos_left="10%",
                pos_right="10%"
            )
        )
    )

    # 5. 生成文件
    grid.render("bilibili_top_danmaku_video.html")
    print("✨ 分析完成！请在浏览器中打开 'bilibili_top_danmaku_video.html' 查看结果。")

# 弹幕数最多的up
def create_top_up_danmaku_chart(csv_path):
    try:
        try:
            df = pd.read_csv(csv_path, encoding='utf-8')
        except:
            df = pd.read_csv(csv_path, encoding='gb18030')

        df['弹幕数'] = pd.to_numeric(df['弹幕数'], errors='coerce').fillna(0).astype(int)
        up_danmaku = df.groupby('UP主昵称')['弹幕数'].sum().reset_index()
        up_top10 = up_danmaku.sort_values(by='弹幕数', ascending=False).head(10)

        up_names = up_top10['UP主昵称'].tolist()
        total_danmaku = [int(v) for v in up_top10['弹幕数']]

    except Exception as e:
        print(f"数据处理出错: {e}")
        return

    bar = (
        Bar()
        .add_xaxis(up_names)
        .add_yaxis(
            "累计总弹幕量",
            total_danmaku,
            color="#26C6DA",
            label_opts=opts.LabelOpts(is_show=True, position="top")
        )
        .set_global_opts(
            title_opts=opts.TitleOpts(
                title="B站每周必看：上榜视频累计弹幕最多的 UP 主 Top 10",
                pos_top="3%",
                pos_left="center"
            ),
            toolbox_opts=opts.ToolboxOpts(is_show=True, pos_top="3%", pos_right="2%"),
            # ★ 核心修复部分 ★
            xaxis_opts=opts.AxisOpts(
                name="UP主",
                axislabel_opts=opts.LabelOpts(
                    interval=0,  # 强制显示所有标签，不再“隔行显示”
                    rotate=30  # 如果名字还是太挤，建议旋转一定角度（如30度）
                )
            ),
            yaxis_opts=opts.AxisOpts(name="弹幕总量"),
            tooltip_opts=opts.TooltipOpts(trigger="axis", axis_pointer_type="shadow")
        )
    )

    grid = (
        Grid(init_opts=opts.InitOpts(width="100%", height="95vh", page_title="UP主弹幕榜"))
        .add(
            bar,
            grid_opts=opts.GridOpts(
                pos_top="20%",
                pos_bottom="15%",  # 增加底部距离，给旋转后的名字留空间
                pos_left="10%",
                pos_right="10%"
            )
        )
    )

    grid.render("bilibili_up_danmaku_rank.html")
    print("✨ 分析成功！")

# 视频点赞量
def create_top_likes_video_chart(csv_path):
    # 1. 加载并清洗数据
    try:
        try:
            df = pd.read_csv(csv_path, encoding='utf-8')
        except:
            df = pd.read_csv(csv_path, encoding='gb18030')

        # 确保点赞数是数字
        df['点赞数'] = pd.to_numeric(df['点赞数'], errors='coerce').fillna(0).astype(int)

        # 按照 BV 号去重，取单视频最高点赞记录
        df_unique = df.sort_values("点赞数", ascending=False).drop_duplicates(subset=["视频BV号"]).head(10)

    except Exception as e:
        print(f"数据处理出错: {e}")
        return

    # 2. 准备数据列表
    titles_short = [str(t)[:12] + "..." if len(str(t)) > 12 else str(t) for t in df_unique["视频标题"]]
    like_counts = [int(v) for v in df_unique["点赞数"]]
    up_names = [str(n) for n in df_unique["UP主昵称"]]
    issues = [str(i) for i in df_unique["期数名称"]]
    full_titles = [str(t) for t in df_unique["视频标题"]]

    # 3. 配置柱状图
    bar = (
        Bar()
        .add_xaxis(titles_short)
        .add_yaxis(
            "点赞数",
            like_counts,
            color="#FF5252",  # 点赞热力红
            label_opts=opts.LabelOpts(is_show=False)
        )
        .set_global_opts(
            title_opts=opts.TitleOpts(
                title="B站每周必看：历史点赞总数最高视频 Top 10",
                subtitle="统计逻辑：单视频点赞总量排行榜",
                pos_top="3%",
                pos_left="center"
            ),
            toolbox_opts=opts.ToolboxOpts(
                is_show=True,
                pos_top="3%",
                pos_right="2%"
            ),
            tooltip_opts=opts.TooltipOpts(
                trigger="axis",
                axis_pointer_type="shadow",
                formatter=JsCode(f"""
                    function (params) {{
                        var idx = params[0].dataIndex;
                        var up_names = {up_names};
                        var issues = {issues};
                        var full_titles = {full_titles};
                        return '<div style="padding:10px; line-height:24px;">' +
                               '<div style="margin-bottom:5px; border-bottom:1px solid #eee;">' +
                               '<b style="color:#FF5252;">' + full_titles[idx] + '</b>' +
                               '</div>' +
                               '👤 <b>UP主：</b>' + up_names[idx] + '<br/>' +
                               '📅 <b>期数：</b>' + issues[idx] + '<br/>' +
                               '❤️ <b>点赞总量：</b>' + params[0].value.toLocaleString() + ' 次' +
                               '</div>';
                    }}
                """)
            ),
            # ★ 重点：强制显示所有标签，并配合倾斜避让 ★
            xaxis_opts=opts.AxisOpts(
                axislabel_opts=opts.LabelOpts(interval=0, rotate=-15, font_size=11)
            ),
            yaxis_opts=opts.AxisOpts(name="点赞数")
        )
    )

    # 4. 使用 Grid 布局自适应
    grid = (
        Grid(init_opts=opts.InitOpts(width="100%", height="95vh", page_title="点赞数视频排行"))
        .add(
            bar,
            grid_opts=opts.GridOpts(
                pos_top="18%",
                pos_bottom="20%",
                pos_left="10%",
                pos_right="10%"
            )
        )
    )

    grid.render("bilibili_top_likes_video.html")
    print("✨ 分析完成！点赞数 Top 10 视频图表已生成。")

# up主点赞量
def create_top_up_likes_chart(csv_path):
    # 1. 提取并聚合数据
    try:
        try:
            df = pd.read_csv(csv_path, encoding='utf-8')
        except:
            df = pd.read_csv(csv_path, encoding='gb18030')

        # 转换点赞数为数值类型
        df['点赞数'] = pd.to_numeric(df['点赞数'], errors='coerce').fillna(0).astype(int)

        # 核心逻辑：按 UP主昵称 分组求点赞数总和
        up_likes = df.groupby('UP主昵称')['点赞数'].sum().reset_index()
        # 筛选点赞总数最高的前 10 名
        up_top10 = up_likes.sort_values(by='点赞数', ascending=False).head(10)

        up_names = up_top10['UP主昵称'].tolist()
        total_likes = [int(v) for v in up_top10['点赞数']]

    except Exception as e:
        print(f"数据聚合出错: {e}")
        return

    # 2. 构造柱状图
    bar = (
        Bar()
        .add_xaxis(up_names)
        .add_yaxis(
            "累计总点赞量",
            total_likes,
            color="#FF5252",  # 沿用点赞热力红
            label_opts=opts.LabelOpts(is_show=True, position="top")
        )
        .set_global_opts(
            title_opts=opts.TitleOpts(
                title="B站每周必看：上榜视频累计点赞最多的 UP 主 Top 10",
                subtitle="统计逻辑：该 UP 主在所有期数中上榜视频的点赞总和",
                pos_top="3%",
                pos_left="center"
            ),
            # 解决工具栏遮挡标题
            toolbox_opts=opts.ToolboxOpts(
                is_show=True,
                pos_top="3%",
                pos_right="2%"
            ),
            # ★ 修复：强制显示所有 UP 主名称 ★
            xaxis_opts=opts.AxisOpts(
                name="UP主",
                axislabel_opts=opts.LabelOpts(
                    interval=0,  # 强制显示所有标签
                    rotate=25,  # 倾斜 25 度防止长名字重叠
                    font_size=12
                )
            ),
            yaxis_opts=opts.AxisOpts(
                name="点赞总量",
                axislabel_opts=opts.LabelOpts(formatter="{value}")
            ),
            tooltip_opts=opts.TooltipOpts(
                trigger="axis",
                axis_pointer_type="shadow",
                formatter="{b}: 共收到 {c} 次点赞"
            )
        )
    )

    # 3. 使用 Grid 容器解决自适应与重叠
    grid = (
        Grid(init_opts=opts.InitOpts(width="100%", height="95vh", page_title="UP主点赞战力榜"))
        .add(
            bar,
            grid_opts=opts.GridOpts(
                pos_top="20%",  # 顶部预留 20% 空间
                pos_bottom="15%",  # 底部预留空间给倾斜的名字
                pos_left="10%",
                pos_right="10%"
            )
        )
    )

    # 4. 生成文件
    grid.render("bilibili_up_likes_rank.html")
    print("✨ 分析成功！'bilibili_up_likes_rank.html' 已生成，请查看。")

# 投币前十的视频
def create_top_coins_chart(csv_path):
    # 1. 加载并清洗数据
    try:
        try:
            df = pd.read_csv(csv_path, encoding='utf-8')
        except:
            df = pd.read_csv(csv_path, encoding='gb18030')

        # 确保投币数是数字，并处理可能存在的空值
        df['投币数'] = pd.to_numeric(df['投币数'], errors='coerce').fillna(0).astype(int)

        # 按照视频去重（同一个视频可能多期上榜），保留投币最高的一次
        df_unique = df.sort_values("投币数", ascending=False).drop_duplicates(subset=["视频BV号"]).head(10)

    except Exception as e:
        print(f"数据处理出错: {e}")
        return

    # 2. 准备多维数据（用于 JsCode 渲染）
    # 转换为 Python 原生 list 确保兼容性
    titles_short = [str(t)[:12] + "..." if len(str(t)) > 12 else str(t) for t in df_unique["视频标题"]]
    coin_counts = [int(v) for v in df_unique["投币数"]]
    up_names = [str(n) for n in df_unique["UP主昵称"]]
    issues = [str(i) for i in df_unique["期数名称"]]
    full_titles = [str(t) for t in df_unique["视频标题"]]
    play_counts = [int(p) for p in df_unique["播放量"]]

    # 3. 配置柱状图
    bar = (
        Bar()
        .add_xaxis(titles_short)
        .add_yaxis(
            "投币数",
            coin_counts,
            color="#FFA726",  # 使用代表金币的橙黄色
            label_opts=opts.LabelOpts(is_show=False)
        )
        .set_global_opts(
            title_opts=opts.TitleOpts(
                title="B站每周必看：历史投币数最高视频 Top 10",
                subtitle="统计逻辑：单视频投币总量排行榜",
                pos_top="3%",
                pos_left="center"
            ),
            toolbox_opts=opts.ToolboxOpts(
                is_show=True,
                pos_top="3%",
                pos_right="2%"
            ),
            tooltip_opts=opts.TooltipOpts(
                trigger="axis",
                axis_pointer_type="shadow",
                formatter=JsCode(f"""
                    function (params) {{
                        var idx = params[0].dataIndex;
                        var up_names = {up_names};
                        var issues = {issues};
                        var full_titles = {full_titles};
                        var plays = {play_counts};
                        return '<div style="padding:10px; line-height:24px;">' +
                               '<div style="margin-bottom:5px; border-bottom:1px solid #eee;">' +
                               '<b style="color:#FFA726;">' + full_titles[idx] + '</b>' +
                               '</div>' +
                               '👤 <b>UP主：</b>' + up_names[idx] + '<br/>' +
                               '📅 <b>期数：</b>' + issues[idx] + '<br/>' +
                               '📺 <b>播放量：</b>' + plays[idx].toLocaleString() + '<br/>' +
                               '🪙 <b>投币总数：</b>' + params[0].value.toLocaleString() + ' 个' +
                               '</div>';
                    }}
                """)
            ),
            xaxis_opts=opts.AxisOpts(axislabel_opts=opts.LabelOpts(rotate=-15)),
            yaxis_opts=opts.AxisOpts(name="投币数")
        )
    )

    # 4. 使用 Grid 布局自适应并避让标题
    grid = (
        Grid(init_opts=opts.InitOpts(width="100%", height="95vh", page_title="投币数排行榜"))
        .add(
            bar,
            grid_opts=opts.GridOpts(
                pos_top="18%",
                pos_bottom="20%",
                pos_left="10%",
                pos_right="10%"
            )
        )
    )

    # 5. 渲染
    grid.render("bilibili_top_coins.html")
    print("✨ 分析成功！请打开 'bilibili_top_coins.html' 查看。")

# 投币前十的up主
def create_top_up_coins_chart(csv_path):
    # 1. 提取并聚合数据
    try:
        try:
            df = pd.read_csv(csv_path, encoding='utf-8')
        except:
            df = pd.read_csv(csv_path, encoding='gb18030')

        # 转换投币数为数值
        df['投币数'] = pd.to_numeric(df['投币数'], errors='coerce').fillna(0).astype(int)

        # 按 UP主昵称 分组求和
        up_coins = df.groupby('UP主昵称')['投币数'].sum().reset_index()
        # 取投币总数最高的前10名
        up_top10 = up_coins.sort_values(by='投币数', ascending=False).head(10)

        up_names = up_top10['UP主昵称'].tolist()
        total_coins = [int(v) for v in up_top10['投币数']]

    except Exception as e:
        print(f"提取数据出错: {e}")
        return

    # 2. 构造柱状图
    bar = (
        Bar()
        .add_xaxis(up_names)
        .add_yaxis(
            "累计总投币量",
            total_coins,
            color="#FFCA28",  # 使用更亮眼的硬币金
            label_opts=opts.LabelOpts(is_show=True, position="top")
        )
        .set_global_opts(
            title_opts=opts.TitleOpts(
                title="B站每周必看：上榜视频累计投币最多的 UP 主 Top 10",
                subtitle="统计逻辑：该 UP 主所有上榜视频的投币总和",
                pos_top="3%",
                pos_left="center"
            ),
            # 工具栏避让
            toolbox_opts=opts.ToolboxOpts(
                is_show=True,
                pos_top="3%",
                pos_right="2%"
            ),
            xaxis_opts=opts.AxisOpts(
                name="UP主",
                axislabel_opts=opts.LabelOpts(rotate=0)
            ),
            yaxis_opts=opts.AxisOpts(
                name="投币总量",
                axislabel_opts=opts.LabelOpts(formatter="{value}")
            ),
            tooltip_opts=opts.TooltipOpts(
                trigger="axis",
                axis_pointer_type="shadow",
                formatter="{b}: 共收获 {c} 枚硬币"
            )
        )
    )

    # 3. 使用 Grid 解决布局与自适应
    grid = (
        Grid(init_opts=opts.InitOpts(width="100%", height="95vh", page_title="UP主投币战力榜"))
        .add(
            bar,
            grid_opts=opts.GridOpts(
                pos_top="20%",  # 留出顶部空间
                pos_bottom="12%",
                pos_left="10%",
                pos_right="10%"
            )
        )
    )

    # 4. 导出
    grid.render("bilibili_up_coins_rank.html")
    print("✨ 分析成功！请打开 'bilibili_up_coins_rank.html' 查看。")

# 转发前十的视频
def create_top_share_video_chart(csv_path):
    # 1. 加载并清洗数据
    try:
        try:
            df = pd.read_csv(csv_path, encoding='utf-8')
        except:
            df = pd.read_csv(csv_path, encoding='gb18030')

        # 确保转发数（分享数）是数字
        # 注意：CSV中的列名可能是'分享数'或'转发数'，这里统一处理
        col_name = '分享数' if '分享数' in df.columns else '转发数'
        df[col_name] = pd.to_numeric(df[col_name], errors='coerce').fillna(0).astype(int)

        # 按照 BV 号去重，取单视频最高记录
        df_unique = df.sort_values(col_name, ascending=False).drop_duplicates(subset=["视频BV号"]).head(10)

    except Exception as e:
        print(f"数据处理出错: {e}")
        return

    # 2. 准备数据
    titles_short = [str(t)[:12] + "..." if len(str(t)) > 12 else str(t) for t in df_unique["视频标题"]]
    share_counts = [int(v) for v in df_unique[col_name]]
    up_names = [str(n) for n in df_unique["UP主昵称"]]
    full_titles = [str(t) for t in df_unique["视频标题"]]

    # 3. 配置柱状图
    bar = (
        Bar()
        .add_xaxis(titles_short)
        .add_yaxis(
            "分享数",
            share_counts,
            color="#43A047",  # 传播绿
            label_opts=opts.LabelOpts(is_show=False)
        )
        .set_global_opts(
            title_opts=opts.TitleOpts(
                title="B站每周必看：历史分享总数最高视频 Top 10",
                subtitle="统计逻辑：单视频分享总量排行榜",
                pos_top="3%",
                pos_left="center"
            ),
            toolbox_opts=opts.ToolboxOpts(is_show=True, pos_top="3%", pos_right="2%"),
            tooltip_opts=opts.TooltipOpts(
                trigger="axis",
                axis_pointer_type="shadow",
                formatter=JsCode(f"""
                    function (params) {{
                        var idx = params[0].dataIndex;
                        var up_names = {up_names};
                        var full_titles = {full_titles};
                        return '<div style="padding:10px; line-height:24px;">' +
                               '<div style="margin-bottom:5px; border-bottom:1px solid #eee;">' +
                               '<b style="color:#43A047;">' + full_titles[idx] + '</b>' +
                               '</div>' +
                               '👤 <b>UP主：</b>' + up_names[idx] + '<br/>' +
                               '🔗 <b>分享总量：</b>' + params[0].value.toLocaleString() + ' 次' +
                               '</div>';
                    }}
                """)
            ),
            xaxis_opts=opts.AxisOpts(
                axislabel_opts=opts.LabelOpts(interval=0, rotate=-15, font_size=11)
            ),
            yaxis_opts=opts.AxisOpts(name="分享数")
        )
    )

    # 4. 使用 Grid 布局自适应
    grid = (
        Grid(init_opts=opts.InitOpts(width="100%", height="95vh", page_title="分享数视频排行"))
        .add(
            bar,
            grid_opts=opts.GridOpts(pos_top="18%", pos_bottom="20%", pos_left="10%", pos_right="10%")
        )
    )

    grid.render("bilibili_top_shares_video.html")
    print("✨ 分析完成！分享数 Top 10 视频图表已生成。")

# 转发前十的up
def create_top_up_shares_chart(csv_path):
    # 1. 提取并聚合数据
    try:
        try:
            df = pd.read_csv(csv_path, encoding='utf-8')
        except:
            df = pd.read_csv(csv_path, encoding='gb18030')

        # 兼容处理列名：分享数 或 转发数
        col_name = '分享数' if '分享数' in df.columns else '转发数'
        df[col_name] = pd.to_numeric(df[col_name], errors='coerce').fillna(0).astype(int)

        # 核心逻辑：按 UP主昵称 分组求转发总和
        up_shares = df.groupby('UP主昵称')[col_name].sum().reset_index()
        # 取前 10 名
        up_top10 = up_shares.sort_values(by=col_name, ascending=False).head(10)

        up_names = up_top10['UP主昵称'].tolist()
        total_shares = [int(v) for v in up_top10[col_name]]

    except Exception as e:
        print(f"提取数据出错: {e}")
        return

    # 2. 构造柱状图
    bar = (
        Bar()
        .add_xaxis(up_names)
        .add_yaxis(
            "累计总分享量",
            total_shares,
            color="#43A047",  # 传播绿
            label_opts=opts.LabelOpts(is_show=True, position="top")
        )
        .set_global_opts(
            title_opts=opts.TitleOpts(
                title="B站每周必看：上榜视频累计分享最多的 UP 主 Top 10",
                subtitle="统计逻辑：该 UP 主在所有期数中上榜视频的分享总和",
                pos_top="3%",
                pos_left="center"
            ),
            # 工具栏配置
            toolbox_opts=opts.ToolboxOpts(
                is_show=True,
                pos_top="3%",
                pos_right="2%"
            ),
            # ★ 修复：强制显示所有 UP 主名称 ★
            xaxis_opts=opts.AxisOpts(
                name="UP主",
                axislabel_opts=opts.LabelOpts(
                    interval=0,  # 强制显示所有标签
                    rotate=25,  # 倾斜避让
                    font_size=12
                )
            ),
            yaxis_opts=opts.AxisOpts(
                name="分享总量",
                axislabel_opts=opts.LabelOpts(formatter="{value}")
            ),
            tooltip_opts=opts.TooltipOpts(
                trigger="axis",
                axis_pointer_type="shadow",
                formatter="{b}: 共被转发/分享 {c} 次"
            )
        )
    )

    # 3. 使用 Grid 布局
    grid = (
        Grid(init_opts=opts.InitOpts(width="100%", height="95vh", page_title="UP主分享战力榜"))
        .add(
            bar,
            grid_opts=opts.GridOpts(
                pos_top="20%",
                pos_bottom="15%",
                pos_left="10%",
                pos_right="10%"
            )
        )
    )

    # 4. 生成文件
    grid.render("bilibili_up_shares_rank.html")
    print("✨ 分析完成！'bilibili_up_shares_rank.html' 已生成。")

# 评论前十的视频
def create_top_comments_video_chart(csv_path):
    # 1. 加载并清洗数据
    try:
        try:
            df = pd.read_csv(csv_path, encoding='utf-8')
        except:
            df = pd.read_csv(csv_path, encoding='gb18030')

        # 确保评论数是数字
        df['评论数'] = pd.to_numeric(df['评论数'], errors='coerce').fillna(0).astype(int)

        # 按照 BV 号去重，取单视频最高评论记录
        df_unique = df.sort_values("评论数", ascending=False).drop_duplicates(subset=["视频BV号"]).head(10)

    except Exception as e:
        print(f"数据处理出错: {e}")
        return

    # 2. 准备数据列表
    titles_short = [str(t)[:12] + "..." if len(str(t)) > 12 else str(t) for t in df_unique["视频标题"]]
    comment_counts = [int(v) for v in df_unique["评论数"]]
    up_names = [str(n) for n in df_unique["UP主昵称"]]
    full_titles = [str(t) for t in df_unique["视频标题"]]

    # 3. 配置柱状图
    bar = (
        Bar()
        .add_xaxis(titles_short)
        .add_yaxis(
            "评论数",
            comment_counts,
            color="#9575CD",  # 优雅紫
            label_opts=opts.LabelOpts(is_show=False)
        )
        .set_global_opts(
            title_opts=opts.TitleOpts(
                title="B站每周必看：历史评论总数最高视频 Top 10",
                subtitle="统计逻辑：单视频评论区活跃度排行",
                pos_top="3%",
                pos_left="center"
            ),
            toolbox_opts=opts.ToolboxOpts(is_show=True, pos_top="3%", pos_right="2%"),
            tooltip_opts=opts.TooltipOpts(
                trigger="axis",
                axis_pointer_type="shadow",
                formatter=JsCode(f"""
                    function (params) {{
                        var idx = params[0].dataIndex;
                        var up_names = {up_names};
                        var full_titles = {full_titles};
                        return '<div style="padding:10px; line-height:24px;">' +
                               '<div style="margin-bottom:5px; border-bottom:1px solid #eee;">' +
                               '<b style="color:#9575CD;">' + full_titles[idx] + '</b>' +
                               '</div>' +
                               '👤 <b>UP主：</b>' + up_names[idx] + '<br/>' +
                               '💬 <b>评论总量：</b>' + params[0].value.toLocaleString() + ' 条' +
                               '</div>';
                    }}
                """)
            ),
            # 强制显示所有标题并旋转
            xaxis_opts=opts.AxisOpts(
                axislabel_opts=opts.LabelOpts(interval=0, rotate=-15, font_size=11)
            ),
            yaxis_opts=opts.AxisOpts(name="评论数")
        )
    )

    # 4. 使用 Grid 布局自适应
    grid = (
        Grid(init_opts=opts.InitOpts(width="100%", height="95vh", page_title="评论数视频排行"))
        .add(
            bar,
            grid_opts=opts.GridOpts(
                pos_top="18%",
                pos_bottom="20%",
                pos_left="10%",
                pos_right="10%"
            )
        )
    )

    grid.render("bilibili_top_comments_video.html")
    print("✨ 分析完成！评论数 Top 10 视频图表已生成。")

# 评论前十的up
def create_top_up_comments_chart(csv_path):
    # 1. 提取并聚合数据
    try:
        try:
            df = pd.read_csv(csv_path, encoding='utf-8')
        except:
            df = pd.read_csv(csv_path, encoding='gb18030')

        # 确保评论数是数字
        df['评论数'] = pd.to_numeric(df['评论数'], errors='coerce').fillna(0).astype(int)

        # 核心逻辑：按 UP主昵称 分组求评论数总和
        up_comments = df.groupby('UP主昵称')['评论数'].sum().reset_index()
        # 取前 10 名
        up_top10 = up_comments.sort_values(by='评论数', ascending=False).head(10)

        up_names = up_top10['UP主昵称'].tolist()
        total_comments = [int(v) for v in up_top10['评论数']]

    except Exception as e:
        print(f"数据聚合出错: {e}")
        return

    # 2. 构造柱状图
    bar = (
        Bar()
        .add_xaxis(up_names)
        .add_yaxis(
            "累计总评论量",
            total_comments,
            color="#9575CD",  # 优雅紫
            label_opts=opts.LabelOpts(is_show=True, position="top")
        )
        .set_global_opts(
            title_opts=opts.TitleOpts(
                title="B站每周必看：上榜视频累计评论最多的 UP 主 Top 10",
                subtitle="统计逻辑：该 UP 主在所有期数中上榜视频的评论总和",
                pos_top="3%",
                pos_left="center"
            ),
            toolbox_opts=opts.ToolboxOpts(
                is_show=True,
                pos_top="3%",
                pos_right="2%"
            ),
            # ★ 修复：强制显示所有 UP 主名称 ★
            xaxis_opts=opts.AxisOpts(
                name="UP主",
                axislabel_opts=opts.LabelOpts(
                    interval=0,  # 强制显示所有标签
                    rotate=25,  # 倾斜避让
                    font_size=12
                )
            ),
            yaxis_opts=opts.AxisOpts(
                name="评论总量",
                axislabel_opts=opts.LabelOpts(formatter="{value}")
            ),
            tooltip_opts=opts.TooltipOpts(
                trigger="axis",
                axis_pointer_type="shadow",
                formatter="{b}: 累计收到 {c} 条评论"
            )
        )
    )

    # 3. 使用 Grid 布局自适应
    grid = (
        Grid(init_opts=opts.InitOpts(width="100%", height="95vh", page_title="UP主评论战力榜"))
        .add(
            bar,
            grid_opts=opts.GridOpts(
                pos_top="20%",
                pos_bottom="15%",
                pos_left="10%",
                pos_right="10%"
            )
        )
    )

    # 4. 生成文件
    grid.render("bilibili_up_comments_rank.html")
    print("✨ 分析完成！'bilibili_up_comments_rank.html' 已成功生成。")


if __name__ == "__main__":
    create_bilibili_fixed_layout("../out_CSV/bilibili_weekly_all_cleaned.csv")
    create_top_up_chart("../out_CSV/bilibili_weekly_all_cleaned.csv")
    create_top_coins_chart("../out_CSV/bilibili_weekly_all_cleaned.csv")
    create_top_up_coins_chart('../out_CSV/bilibili_weekly_all_cleaned.csv')
    create_top_danmaku_video_chart('../out_CSV/bilibili_weekly_all_cleaned.csv')
    create_top_up_danmaku_chart('../out_CSV/bilibili_weekly_all_cleaned.csv')
    create_top_likes_video_chart('../out_CSV/bilibili_weekly_all_cleaned.csv')
    create_top_up_likes_chart('../out_CSV/bilibili_weekly_all_cleaned.csv')
    create_top_share_video_chart('../out_CSV/bilibili_weekly_all_cleaned.csv')
    create_top_up_shares_chart('../out_CSV/bilibili_weekly_all_cleaned.csv')
    create_top_comments_video_chart('../out_CSV/bilibili_weekly_all_cleaned.csv')
    create_top_up_comments_chart('../out_CSV/bilibili_weekly_all_cleaned.csv')


