import pandas as pd
from pyecharts.charts import Pie, Bar
from pyecharts import options as opts


# 视频分类占比
def create_category_double_view(csv_path):
    try:
        # 1. 稳健读取数据
        df = pd.read_csv(csv_path, encoding="utf-8-sig")

        # 提取“视频分区”字段并统计 Top 10
        counts = df['视频分区'].value_counts().head(10).reset_index()
        counts.columns = ['name', 'value']

        names = counts['name'].tolist()
        values = counts['value'].tolist()
        data_pair = [list(z) for z in zip(names, values)]

    except Exception as e:
        print(f"❌ 数据提取失败: {e}")
        return

    # 2. 构建左侧：扇环图 (展示份额占比)
    pie = (
        Pie(init_opts=opts.InitOpts(width="100%", height="550px"))
        .add(
            "",
            data_pair,
            radius=["40%", "70%"],
            itemstyle_opts=opts.ItemStyleOpts(border_radius=8, border_width=2, border_color="#fff"),
            label_opts=opts.LabelOpts(formatter="{b}: {d}%", font_weight="bold", font_size=13)
        )
        # 使用一套清新的蓝绿紫渐变色系
        .set_colors(["#5470c6", "#91cc75", "#fac858", "#ee6666", "#73c0de", "#3ba272", "#fc8452", "#9a60b4", "#ea7ccc",
                     "#51689b"])
        .set_global_opts(
            title_opts=opts.TitleOpts(title="视频分区占比", pos_left="center"),
            legend_opts=opts.LegendOpts(is_show=False)
        )
    )

    # 3. 构建右侧：横向柱状图 (展示精确数量)
    bar = (
        Bar(init_opts=opts.InitOpts(width="100%", height="550px"))
        .add_xaxis(names[::-1])  # 翻转列表让第一名显示在最上
        .add_yaxis(
            "上榜视频数",
            values[::-1],
            label_opts=opts.LabelOpts(position="right", font_weight="bold"),
            color="#5470c6",  # 使用与扇环图榜首呼应的蓝色
            category_gap="40%"
        )
        .reversal_axis()  # 转为横向
        .set_global_opts(
            title_opts=opts.TitleOpts(title="上榜数量精准排行", pos_left="center"),
            xaxis_opts=opts.AxisOpts(name="视频数量(个)", splitline_opts=opts.SplitLineOpts(is_show=True)),
            yaxis_opts=opts.AxisOpts(axislabel_opts=opts.LabelOpts(font_weight="bold", font_size=12)),
            legend_opts=opts.LegendOpts(is_show=False)
        )
    )

    # 4. 提取图表的内部 HTML 源码
    pie_html = pie.render_embed()
    bar_html = bar.render_embed()

    # 5. 使用原生 HTML + CSS 构建大厂级悬浮卡片布局
    html_template = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>B站视频分区全景看板</title>
        <script src="https://assets.pyecharts.org/assets/v5/echarts.min.js"></script>
        <style>
            body {{
                background-color: #f4f6f9; /* 浅灰底色，凸显卡片 */
                font-family: 'Microsoft YaHei', sans-serif;
                margin: 0;
                padding: 40px;
            }}
            .header {{
                text-align: center;
                margin-bottom: 30px;
                color: #2c3e50;
            }}
            /* Flexbox 左右排版 */
            .dashboard-container {{
                display: flex;
                justify-content: space-between;
                gap: 25px;
            }}
            /* 悬浮白卡片样式 */
            .card {{
                background: #ffffff;
                border-radius: 12px;
                box-shadow: 0 8px 24px rgba(149, 157, 165, 0.2);
                padding: 20px;
                width: 48%; /* 左右各占将近一半 */
                box-sizing: border-box;
            }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1 style="margin-bottom: 10px;">📈 B站每周必看：视频分区生态大揭秘</h1>
            <span style="color: #666;">左侧展示核心分区的生态统治力，右侧展示实际上榜视频数量</span>
        </div>

        <div class="dashboard-container">
            <div class="card">
                {pie_html}
            </div>

            <div class="card">
                {bar_html}
            </div>
        </div>
    </body>
    </html>
    """

    # 6. 保存输出
    output_file = "all_in/category_double_view_dashboard.html"
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(html_template)

    print(f"✨ 极致排版的双视图看板已生成：{output_file}")


# 上榜最频繁UP主
def create_perfect_side_by_side_dashboard(csv_path):
    try:
        # 1. 稳健读取数据
        df = pd.read_csv(csv_path, encoding="utf-8-sig")

        # 统计频次并取 Top 10
        raw_counts = df['UP主昵称'].value_counts()
        if raw_counts.empty:
            print("⚠️ CSV中未找到UP主数据")
            return

        up_counts = raw_counts.head(10).reset_index()
        up_counts.columns = ['name', 'value']

        up_names = up_counts['name'].tolist()
        counts = up_counts['value'].tolist()
        data_pair = [list(z) for z in zip(up_names, counts)]

    except Exception as e:
        print(f"❌ 数据提取失败: {e}")
        return

    # 2. 构建左侧扇环图 (份额占比)
    pie = (
        # 宽度设为100%，自适应外部的卡片宽度
        Pie(init_opts=opts.InitOpts(width="100%", height="550px"))
        .add(
            "",
            data_pair,
            radius=["40%", "70%"],
            # 增加圆角，提升现代感
            itemstyle_opts=opts.ItemStyleOpts(border_radius=8, border_width=2, border_color="#fff"),
            label_opts=opts.LabelOpts(formatter="{b}: {d}%", font_weight="bold")
        )
        .set_colors(["#FF7043", "#FFAB91", "#FFD54F", "#81C784", "#4DB6AC", "#64B5F6", "#9575CD", "#F06292", "#A1887F",
                     "#90A4AE"])
        .set_global_opts(
            title_opts=opts.TitleOpts(title="上榜最频繁UP主", pos_left="center"),
            legend_opts=opts.LegendOpts(is_show=False)
        )
    )

    # 3. 构建右侧横向柱状图 (精准次数)
    bar = (
        Bar(init_opts=opts.InitOpts(width="100%", height="550px"))
        .add_xaxis(up_names[::-1])  # 翻转列表让第一名显示在最上
        .add_yaxis(
            "上榜次数",
            counts[::-1],
            label_opts=opts.LabelOpts(position="right", font_weight="bold"),
            color="#FF7043",
            category_gap="40%"
        )
        .reversal_axis()  # 转为横向
        .set_global_opts(
            title_opts=opts.TitleOpts(title="上榜次数精确排行", pos_left="center"),
            xaxis_opts=opts.AxisOpts(name="次数", splitline_opts=opts.SplitLineOpts(is_show=True)),
            yaxis_opts=opts.AxisOpts(axislabel_opts=opts.LabelOpts(font_weight="bold", font_size=12)),
            legend_opts=opts.LegendOpts(is_show=False)
        )
    )

    # 4. 关键：提取图表的内部 HTML 源码
    pie_html = pie.render_embed()
    bar_html = bar.render_embed()

    # 5. 使用原生 HTML + CSS 构建完美布局
    html_template = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>UP主上榜频次全景看板</title>
        <script src="https://assets.pyecharts.org/assets/v5/echarts.min.js"></script>
        <style>
            body {{
                background-color: #f0f2f5;
                font-family: 'Microsoft YaHei', sans-serif;
                margin: 0;
                padding: 40px;
            }}
            .header {{
                text-align: center;
                margin-bottom: 40px;
                color: #333;
            }}
            /* 使用 Flexbox 进行左右排版，稳定且自适应 */
            .dashboard-container {{
                display: flex;
                justify-content: space-between;
                gap: 30px;
            }}
            .card {{
                background: #ffffff;
                border-radius: 16px; /* 卡片圆角 */
                box-shadow: 0 10px 30px rgba(0,0,0,0.08); /* 高级悬浮阴影 */
                padding: 25px;
                width: 48%; /* 左右各占一半 */
                box-sizing: border-box;
            }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1 style="margin-bottom: 10px;">🏆 必看常青树：UP 主上榜频次分析</h1>
            <span style="color: #666;">左侧展示内容占有率，右侧展示实际上榜次数</span>
        </div>

        <div class="dashboard-container">
            <div class="card">
                {pie_html}
            </div>

            <div class="card">
                {bar_html}
            </div>
        </div>
    </body>
    </html>
    """

    # 6. 保存为最终看板
    output_file = "all_in/up_frequency_pro_dashboard.html"
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(html_template)

    print(f"✨ 极致排版看板已生成：{output_file}")


if __name__ == "__main__":
    create_category_double_view("./out_CSV/bilibili_weekly_all_cleaned.csv")

    # 路径指向你的清洗输出目录
    CSV_FILE = "./out_CSV/bilibili_weekly_all_cleaned.csv"
    create_perfect_side_by_side_dashboard(CSV_FILE)


