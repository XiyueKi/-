import pandas as pd
from pyecharts.charts import Bar, Timeline, Grid
from pyecharts import options as opts
from pyecharts.commons.utils import JsCode


def create_ultimate_bilibili_dashboard(csv_path):
    # 1. 加载并预处理数据
    try:
        # utf-8-sig 兼容清洗脚本生成的格式
        df = pd.read_csv(csv_path, encoding='utf-8-sig')

        # 定义需要统计的所有指标
        metrics = ["播放量", "点赞数", "投币数", "收藏数", "弹幕数", "分享数", "评论数"]

        # 强制转换数值类型，确保绘图不报错
        for m in metrics:
            if m in df.columns:
                df[m] = pd.to_numeric(df[m], errors='coerce').fillna(0).astype(int)
            else:
                # 如果某个指标缺失，补 0（防御性编程）
                df[m] = 0

    except Exception as e:
        print(f"❌ 读取 CSV 失败，请检查文件路径或格式: {e}")
        return

    # 2. 为不同指标定义专属配色方案
    color_map = {
        "播放量": "#FB7299", "点赞数": "#FF5252", "投币数": "#FFCA28",
        "收藏数": "#FFA726", "弹幕数": "#00B5AD", "分享数": "#43A047", "评论数": "#9575CD"
    }

    # 3. 初始化时间轴（作为切换菜单）
    tl = Timeline(init_opts=opts.InitOpts(width="100%", height="96vh", theme="white"))

    for metric in metrics:
        # --- A. 视频数据处理 (左侧) ---
        # 按照指标排序，去重 BV 号
        df_v = df.sort_values(metric, ascending=False).drop_duplicates(subset=["视频BV号"]).head(10)
        v_x = [str(t)[:8] + "..." if len(str(t)) > 8 else str(t) for t in df_v["视频标题"]]
        v_y = [int(v) for v in df_v[metric]]
        v_ups = [str(n) for n in df_v["UP主昵称"]]
        v_fulls = [str(t) for t in df_v["视频标题"]]

        # --- B. UP 主数据处理 (右侧) ---
        df_up = df.groupby('UP主昵称')[metric].sum().reset_index().sort_values(metric, ascending=False).head(10)
        up_x = df_up['UP主昵称'].tolist()
        up_y = [int(v) for v in df_up[metric]]

        # --- C. 左侧柱状图 (视频) ---
        bar_v = (
            Bar()
            .add_xaxis(v_x)
            .add_yaxis(metric, v_y, color=color_map[metric], label_opts=opts.LabelOpts(is_show=False))
            .set_global_opts(
                title_opts=opts.TitleOpts(title=f"🎬 视频 {metric} 排行", pos_left="15%", pos_top="5%"),
                xaxis_opts=opts.AxisOpts(axislabel_opts=opts.LabelOpts(interval=0, rotate=-15)),
                tooltip_opts=opts.TooltipOpts(
                    trigger="axis",
                    formatter=JsCode(f"""
                        function (params) {{
                            var idx = params[0].dataIndex;
                            var ups = {v_ups};
                            var fulls = {v_fulls};
                            return '<div style="padding:10px;">' +
                                   '<b style="color:{color_map[metric]};">' + fulls[idx] + '</b><br/>' +
                                   '👤 UP主：' + ups[idx] + '<br/>' +
                                   '🔥 {metric}：' + params[0].value.toLocaleString() + '</div>';
                        }}
                    """))
            )
        )

        # --- D. 右侧柱状图 (UP主) ---
        bar_up = (
            Bar()
            .add_xaxis(up_x)
            .add_yaxis(metric, up_y, color=color_map[metric], label_opts=opts.LabelOpts(is_show=True, position="top"))
            .set_global_opts(
                title_opts=opts.TitleOpts(title=f"👑累计{metric}最多的UP主", pos_left="65%", pos_top="5%"),
                xaxis_opts=opts.AxisOpts(axislabel_opts=opts.LabelOpts(interval=0, rotate=15)),
                tooltip_opts=opts.TooltipOpts(trigger="axis")
            )
        )

        # --- E. 组合布局 ---
        grid = (
            Grid()
            .add(bar_v, grid_opts=opts.GridOpts(pos_left="5%", pos_right="55%", pos_top="18%", pos_bottom="15%"))
            .add(bar_up, grid_opts=opts.GridOpts(pos_left="55%", pos_right="5%", pos_top="18%", pos_bottom="15%"))
        )

        # 将组合图加入 Timeline 标签
        tl.add(grid, metric)

    # 4. 设置 Timeline 交互样式 (修正报错点)
    tl.add_schema(
        is_auto_play=False,  # 手动切换
        pos_bottom="2%",
        width="80%",
        pos_left="center",
        label_opts=opts.TextStyleOpts(color="#333", font_size=12, font_weight="bold"),
        symbol="diamond",  # 节点形状
        symbol_size=10
    )

    # 5. 输出
    output_name = "bilibili_all_in_one_dashboard.html"
    tl.render(output_name)
    print(f"✅ 终极全指标看板已生成：{output_name}")


if __name__ == "__main__":
    # 请确保 CSV 文件在 ./out_CSV 目录下
    CSV_FILE = "./out_CSV/bilibili_weekly_all_cleaned.csv"
    create_ultimate_bilibili_dashboard(CSV_FILE)
