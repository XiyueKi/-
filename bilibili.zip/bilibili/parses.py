import json
import pandas as pd
import os
import re
from datetime import datetime


# ========== 1. 核心清洗工具函数（处理格式异常） ==========
def fix_time_format(value):
    """统一时间格式：返回标准时间字符串或 None"""
    if pd.isna(value) or value in ["", "0", 0]:
        return None
    # 先尝试按时间戳解析
    if str(value).isdigit():
        ts = int(value)
        # 过滤极端时间戳（2009年之前或未来10年）
        if 1230739200 <= ts <= 2177452800:
            return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")
        else:
            return None
    # 再尝试按常见字符串格式解析
    try:
        dt = pd.to_datetime(value, errors="coerce")
        if pd.notna(dt):
            return dt.strftime("%Y-%m-%d %H:%M:%S")
        else:
            return None
    except:
        return None

def fix_numeric_format(value):
    """统一数值格式：返回 int 或 0"""
    if pd.isna(value) or value in ["", "NaN", "null"]:
        return 0
    s = str(value)
    # 移除千分位逗号、汉字单位
    s = re.sub(r'[,，]', '', s)
    s = re.sub(r'[万Ww]', '0000', s)
    s = re.sub(r'[亿Yy]', '00000000', s)
    # 提取纯数字
    nums = re.findall(r'\d+', s)
    if nums:
        return int(nums[0])
    else:
        return 0

def clean_text_format(text):
    """清洗文本：移除非法字符、统一空白、修复乱码"""
    if pd.isna(text):
        return ""
    text = str(text)
    # 移除控制字符
    text = re.compile(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]').sub('', text)
    # 统一空白：全角转半角，连续空格/换行/制表符转为单个空格
    text = re.compile(r'[\u3000\t\r\n]+').sub(' ', text)
    text = re.compile(r'\s+').sub(' ', text).strip()
    # 修复常见乱码（可选）
    text = text.encode("utf-8", "ignore").decode("utf-8")
    return text

def clean_illegal_chars(text):
    """清洗Excel/CSV不支持的非法字符（兼容旧代码）"""
    return clean_text_format(text)


# ========== 2. 单期数据提取与清洗 ==========
def extract_and_clean_single_period(file_path):
    """提取单期JSON并清洗格式异常，返回清洗后的视频列表"""
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        # 校验数据有效性
        if data.get("code") != 0 or "data" not in data:
            print(f"⚠️ 文件 {os.path.basename(file_path)} 接口返回异常，跳过")
            return []

        config = data["data"]["config"]
        video_list = data["data"]["list"]
        cleaned_videos = []

        # 提取并清洗该期所有视频
        for video in video_list:
            # 1. 核心标识缺失：直接跳过该视频
            if not video.get("aid") or not video.get("bvid"):
                continue

            video_info = {
                # 期数信息
                "期数编号": fix_numeric_format(config.get("number", 0)),
                "期数名称": clean_text_format(config.get("name", "")),
                "期数开始时间": fix_time_format(config.get("stime", 0)),
                "期数结束时间": fix_time_format(config.get("etime", 0)),

                # 视频基础信息
                "视频AV号": clean_text_format(video.get("aid", "")),
                "视频BV号": clean_text_format(video.get("bvid", "")),
                "视频标题": clean_text_format(video.get("title", "标题缺失")),
                "视频分区": clean_text_format(video.get("tname", "未知分区")),
                "分区二级分类": clean_text_format(video.get("tnamev2", "未知子分区")),
                "发布时间": fix_time_format(video.get("pubdate", 0)),
                "视频时长(秒)": fix_numeric_format(video.get("duration", 0)),

                # UP主信息
                "UP主ID": fix_numeric_format(video.get("owner", {}).get("mid", 0)),
                "UP主昵称": clean_text_format(video.get("owner", {}).get("name", "未知UP主")),

                # 统计数据（统一数值格式）
                "播放量": fix_numeric_format(video.get("stat", {}).get("view", 0)),
                "弹幕数": fix_numeric_format(video.get("stat", {}).get("danmaku", 0)),
                "评论数": fix_numeric_format(video.get("stat", {}).get("reply", 0)),
                "收藏数": fix_numeric_format(video.get("stat", {}).get("favorite", 0)),
                "投币数": fix_numeric_format(video.get("stat", {}).get("coin", 0)),
                "分享数": fix_numeric_format(video.get("stat", {}).get("share", 0)),
                "点赞数": fix_numeric_format(video.get("stat", {}).get("like", 0)),
                "历史最高排名": fix_numeric_format(video.get("stat", {}).get("his_rank", 0)),

                # 其他信息
                "推荐理由": clean_text_format(video.get("rcmd_reason", "")),
                "发布位置": clean_text_format(video.get("pub_location", "未知地点"))
            }
            cleaned_videos.append(video_info)

        print(f"✅ 提取并清洗完成：{os.path.basename(file_path)}（{len(cleaned_videos)}条有效视频）")
        return cleaned_videos

    except json.JSONDecodeError:
        print(f"❌ {os.path.basename(file_path)} JSON格式错误，无法解析")
        return []
    except Exception as e:
        print(f"❌ 处理 {os.path.basename(file_path)} 出错：{str(e)}")
        return []


# ========== 3. 合并所有期数并保存为单个文件 ==========
def merge_all_periods_to_single_file(json_folder: str):
    """
    合并所有期数的JSON数据，自动清洗格式异常，保存为单个CSV和Excel文件
    :param json_folder: JSON文件存放路径
    """
    # 1. 获取所有符合规则的JSON文件（按期数排序）
    json_files = []
    for filename in os.listdir(json_folder):
        if filename.startswith("ep") and filename.endswith(".json"):
            # 提取期数数字用于排序
            try:
                period_num = int(re.findall(r'ep(\d+)\.json', filename)[0])
                json_files.append((period_num, os.path.join(json_folder, filename)))
            except:
                print(f"⚠️ 文件 {filename} 命名不规范，跳过")

    # 按期数升序排序
    json_files.sort(key=lambda x: x[0])
    total_files = len(json_files)
    if total_files == 0:
        print("⚠️ 未找到符合规则的JSON文件")
        return

    # 2. 提取并清洗所有期数的视频数据
    all_cleaned_videos = []
    for period_num, file_path in json_files:
        period_videos = extract_and_clean_single_period(file_path)
        all_cleaned_videos.extend(period_videos)

    # 3. 转换为DataFrame并做最终校验
    df_all = pd.DataFrame(all_cleaned_videos)
    # 过滤核心字段缺失的行
    df_all = df_all.dropna(subset=["视频BV号", "播放量"], how="any")
    # 过滤播放量异常（负数）
    df_all = df_all[df_all["播放量"] >= 0]
    # 按期数编号排序
    df_all = df_all.sort_values(by="期数编号").reset_index(drop=True)

    # 4. 确保输出目录存在
    output_dir = "./out_CSV"
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # 5. 保存为单个CSV和Excel文件
    csv_path = os.path.join(output_dir, "bilibili_weekly_all_cleaned.csv")
    excel_path = os.path.join(output_dir, "bilibili_weekly_all_cleaned.xlsx")

    # 保存CSV（utf-8-sig编码避免中文乱码）
    df_all.to_csv(csv_path, index=False, encoding="utf-8-sig")
    # 保存Excel（openpyxl引擎支持大文件）
    df_all.to_excel(excel_path, index=False, engine="openpyxl")

    # 输出统计信息
    print(f"\n🎉 所有期数合并与清洗完成！")
    print(f"📊 统计：共处理 {total_files} 期，总计 {len(all_cleaned_videos)} 条原始视频，清洗后保留 {len(df_all)} 条有效数据")
    print(f"💾 文件保存路径：")
    print(f"   CSV：{csv_path}")
    print(f"   Excel：{excel_path}")


# ========== 4. 执行合并操作 ==========
if __name__ == "__main__":
    # 替换为你的JSON文件夹路径
    JSON_FOLDER = "./data_json"
    merge_all_periods_to_single_file(json_folder=JSON_FOLDER)
