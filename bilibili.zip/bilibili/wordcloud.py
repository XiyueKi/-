import pandas as pd
import jieba
import re
from collections import Counter
from pyecharts import options as opts
from pyecharts.charts import WordCloud


CSV_PATH = "./out_CSV/bilibili_weekly_all_cleaned.csv"
OUT_FILE = "all_in/wordcloud_switch.html"


# ==========================
# 标题词云
# ==========================
def create_title_cloud():
    df = pd.read_csv(CSV_PATH, encoding="utf-8")

    all_titles = "".join(df["视频标题"].dropna().astype(str))
    clean_text = re.sub(r'[^\u4e00-\u9fa5a-zA-Z]', ' ', all_titles)

    try:
        with open("stopword.txt", "r", encoding="utf-8") as f:
            stopwords = set(f.read().splitlines())
    except:
        stopwords = set()

    stopwords.update({"视频", "一个", "什么", "怎么", "如何", "真的"})

    words = jieba.lcut(clean_text)
    filtered = [w for w in words if len(w) > 1 and w not in stopwords and not w.isdigit()]
    word_counts = Counter(filtered).most_common(150)

    c = (
        WordCloud(init_opts=opts.InitOpts(width="100%", height="800px", bg_color="#ffffff"))
        .add("", word_counts, word_size_range=[20, 110], shape="circle")
        .set_global_opts(
            title_opts=opts.TitleOpts(
                title="视频标题核心关键词",
                pos_left="center"
            )
        )
    )
    return c


# ==========================
# 推荐理由词云
# ==========================
def create_reason_cloud():
    df = pd.read_csv(CSV_PATH, encoding="utf-8")

    all_reasons = " ".join(df["推荐理由"].dropna().astype(str))
    clean_text = re.sub(r'[^\u4e00-\u9fa5a-zA-Z]', ' ', all_reasons)

    try:
        with open("stopword.txt", "r", encoding="utf-8") as f:
            stopwords = set(f.read().splitlines())
    except:
        stopwords = set()

    stopwords.update({"推荐", "理由", "必看", "视频", "真的"})

    words = jieba.lcut(clean_text)
    filtered = [w for w in words if len(w) > 1 and w not in stopwords and not w.isdigit()]
    word_counts = Counter(filtered).most_common(120)

    c = (
        WordCloud(init_opts=opts.InitOpts(width="100%", height="800px", bg_color="#ffffff"))
        .add("推荐理由关键词", word_counts, word_size_range=[20, 110], shape="circle")
        .set_global_opts(
            title_opts=opts.TitleOpts(
                title="推荐理由核心魅力关键词",
                pos_left="center"
            )
        )
    )
    return c


# ==========================
# 生成可切换页面
# ==========================
def build_switch_html(title_embed, reason_embed):

    html = f"""
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>词云切换展示</title>
<style>
body {{
    margin:0;
    font-family: Arial;
}}
.controls {{
    text-align:center;
    margin:15px;
}}
button {{
    padding:8px 16px;
    margin:0 10px;
    border-radius:6px;
    border:1px solid #ccc;
    cursor:pointer;
}}
.container {{
    position:relative;
    width:100%;
    height:800px;
}}
.chart {{
    position:absolute;
    width:100%;
    height:100%;
    transition:opacity 0.6s ease;
    opacity:0;
}}
.chart.show {{
    opacity:1;
}}
</style>
</head>

<body>

<div class="controls">
    <button onclick="switchTo('c1')">标题词云</button>
    <button onclick="switchTo('c2')">推荐理由词云</button>
</div>

<div class="container">
    <div id="c1" class="chart show">
        {title_embed}
    </div>

    <div id="c2" class="chart">
        {reason_embed}
    </div>
</div>

<script>
function switchTo(id){{
    document.querySelectorAll('.chart').forEach(el => el.classList.remove('show'));
    document.getElementById(id).classList.add('show');
}}
</script>

</body>
</html>
"""

    with open(OUT_FILE, "w", encoding="utf-8") as f:
        f.write(html)

    print("✅ 已生成可切换词云页面：", OUT_FILE)


# ==========================
# 主程序
# ==========================
if __name__ == "__main__":
    title_cloud = create_title_cloud()
    reason_cloud = create_reason_cloud()

    build_switch_html(
        title_cloud.render_embed(),
        reason_cloud.render_embed()
    )
