from DrissionPage import Chromium
from concurrent.futures import ThreadPoolExecutor
import functools
import json
import re
import time
import random
import ast


def craw(browser, res_url):
    """
    爬取指定页面，监听并返回目标URL
    :param browser: 复用的Chromium浏览器实例（避免多线程创建多个浏览器）
    :param res_url: 要访问的B站每周热门页面URL
    :return: 监听到的目标URL，失败则返回None
    """
    try:
        # 随机睡眠
        random_sleep()

        # 新建标签页（复用浏览器实例，减少资源占用）
        n_tab = browser.new_tab()
        # 监听包含"one?number="的数据包
        n_tab.listen.start('one?number=')

        # 随机睡眠
        random_sleep()

        # 打开目标网址（设置超时，避免卡壳）
        n_tab.get(res_url, timeout=10)
        # 等待监听结果（超时5秒，避免无限等待）
        response = n_tab.listen.wait(timeout=5)

        if response and hasattr(response, 'url'):
            target_url = response.url
        else:
            target_url = None

        # 随机睡眠
        random_sleep()

        # 关闭标签页释放资源
        n_tab.close()
        return target_url

    except Exception as e:
        # 捕获异常，打印错误信息，避免单线程崩溃
        print(f'爬取 {res_url} 失败: {str(e)}')
        # 确保异常时也关闭标签页
        try:
            n_tab.close()
        except:
            pass
        return None


def parse(url_result):
    num = re.search(r'number=(\d+)', url_result)
    ep = num.group(1)
    n_tab = Chromium().new_tab()

    random_sleep()

    n_tab.get(url_result)

    random_sleep()

    data = n_tab.json

    random_sleep()
    print(num)
    with open(f'./data_json/ep{ep}.json', 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

    random_sleep()

    n_tab.close()


def random_sleep(min_sec=1, max_sec=5):
    """
    简易随机睡眠函数
    :param min_sec: 最小睡眠秒数（默认1秒）
    :param max_sec: 最大睡眠秒数（默认5秒）
    """
    # 生成 [min_sec, max_sec] 范围内的随机浮点数
    sleep_time = random.uniform(min_sec, max_sec)
    # 执行睡眠
    time.sleep(sleep_time)
    # 可选：打印睡眠信息（方便调试，不需要可删除）
    print(f"已随机睡眠 {sleep_time:.2f} 秒")


if __name__ == '__main__':
    # 1. 生成要爬取的B站每周热门页面URL列表（1-19页）
    url_list = [f'https://www.bilibili.com/v/popular/weekly?num={page}'
                for page in range(1, 342+1)]

    # 2. 创建单个Chromium浏览器实例（复用，避免多线程创建多个浏览器）
    browser = Chromium()

    cookies = [
  {
    "domain": ".bilibili.com",
    "expirationDate": 1802572426.987733,
    "hostOnly": False,
    "httpOnly": False,
    "name": "buvid3",
    "path": "/",
    "sameSite": "unspecified",
    "secure": False,
    "session": False,
    "storeId": "0",
    "value": "17685324-3BEA-4C34-332F-CD7A33B6791F26200infoc"
  },
  {
    "domain": ".bilibili.com",
    "expirationDate": 1802572426.987823,
    "hostOnly": False,
    "httpOnly": False,
    "name": "b_nut",
    "path": "/",
    "sameSite": "unspecified",
    "secure": False,
    "session": False,
    "storeId": "0",
    "value": "1771036426"
  },
  {
    "domain": ".bilibili.com",
    "expirationDate": 1802572427,
    "hostOnly": False,
    "httpOnly": False,
    "name": "_uuid",
    "path": "/",
    "sameSite": "unspecified",
    "secure": False,
    "session": False,
    "storeId": "0",
    "value": "34914E2C-2546-CDF1-EBD1-341718D4CD3927137infoc"
  },
  {
    "domain": ".bilibili.com",
    "expirationDate": 1805596427.708639,
    "hostOnly": False,
    "httpOnly": False,
    "name": "buvid_fp",
    "path": "/",
    "sameSite": "unspecified",
    "secure": False,
    "session": False,
    "storeId": "0",
    "value": "593011556d88a67f745576c5217ef9b2"
  },
  {
    "domain": ".bilibili.com",
    "expirationDate": 1805678578.272655,
    "hostOnly": False,
    "httpOnly": False,
    "name": "buvid4",
    "path": "/",
    "sameSite": "unspecified",
    "secure": False,
    "session": False,
    "storeId": "0",
    "value": "B0DFDAD2-51A8-B720-E235-338E01B1672127155-026021410-VIfHLwfSIkf0Ql7zg401uA%3D%3D"
  },
  {
    "domain": ".bilibili.com",
    "expirationDate": 1771295628,
    "hostOnly": False,
    "httpOnly": False,
    "name": "bili_ticket",
    "path": "/",
    "sameSite": "unspecified",
    "secure": False,
    "session": False,
    "storeId": "0",
    "value": "eyJhbGciOiJIUzI1NiIsImtpZCI6InMwMyIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NzEyOTU2MjcsImlhdCI6MTc3MTAzNjM2NywicGx0IjotMX0.uHS_k1hTGAzIIQ5pg-qUj2B5Q7eVVFAl68G7xxAKOVw"
  },
  {
    "domain": ".bilibili.com",
    "expirationDate": 1771295628,
    "hostOnly": False,
    "httpOnly": False,
    "name": "bili_ticket_expires",
    "path": "/",
    "sameSite": "unspecified",
    "secure": False,
    "session": False,
    "storeId": "0",
    "value": "1771295567"
  },
  {
    "domain": ".bilibili.com",
    "expirationDate": 1802654575,
    "hostOnly": False,
    "httpOnly": False,
    "name": "home_feed_column",
    "path": "/",
    "sameSite": "unspecified",
    "secure": False,
    "session": False,
    "storeId": "0",
    "value": "5"
  },
  {
    "domain": ".bilibili.com",
    "expirationDate": 1802654575,
    "hostOnly": False,
    "httpOnly": False,
    "name": "browser_resolution",
    "path": "/",
    "sameSite": "unspecified",
    "secure": False,
    "session": False,
    "storeId": "0",
    "value": "1707-932"
  },
  {
    "domain": ".bilibili.com",
    "expirationDate": 1802612426,
    "hostOnly": False,
    "httpOnly": False,
    "name": "CURRENT_FNVAL",
    "path": "/",
    "sameSite": "unspecified",
    "secure": False,
    "session": False,
    "storeId": "0",
    "value": "4048"
  },
  {
    "domain": ".bilibili.com",
    "expirationDate": 1802612426,
    "hostOnly": False,
    "httpOnly": False,
    "name": "CURRENT_QUALITY",
    "path": "/",
    "sameSite": "unspecified",
    "secure": False,
    "session": False,
    "storeId": "0",
    "value": "0"
  },
  {
    "domain": ".bilibili.com",
    "expirationDate": 1805636427.500203,
    "hostOnly": False,
    "httpOnly": False,
    "name": "rpdid",
    "path": "/",
    "sameSite": "unspecified",
    "secure": False,
    "session": False,
    "storeId": "0",
    "value": "|(J~RYkkYuuR0J'u~~u|~YRk~"
  },
  {
    "domain": ".bilibili.com",
    "expirationDate": 1771687690.902657,
    "hostOnly": False,
    "httpOnly": True,
    "name": "SESSDATA",
    "path": "/",
    "sameSite": "no_restriction",
    "secure": True,
    "session": False,
    "storeId": "0",
    "value": "ebcd4674%2C1786634890%2C77f0f%2A22CjBAUgXmBBJKPm7Q2AX9wIlvVG3HxvxtkgFrP0YlRsSMt7G-H_KneOstUJs2GXBr6PUSVmMtSGZIamQwWHk3OU9iZGpTT1pUZXNNYVE4WXNnZVMtRm0zOXMxb25OS3FpN0VRTmJkTlh0MnJDbk1ob3RoUkN4U0tPT3g4Z0pVbl9ITWV5TlBFc2dRIIEC"
  },
  {
    "domain": ".bilibili.com",
    "expirationDate": 1771687690.902745,
    "hostOnly": False,
    "httpOnly": False,
    "name": "bili_jct",
    "path": "/",
    "sameSite": "unspecified",
    "secure": False,
    "session": False,
    "storeId": "0",
    "value": "c57fdf9f0160dd28834bb99af637a5cb"
  },
  {
    "domain": ".bilibili.com",
    "expirationDate": 1771687690.902775,
    "hostOnly": False,
    "httpOnly": False,
    "name": "DedeUserID",
    "path": "/",
    "sameSite": "no_restriction",
    "secure": True,
    "session": False,
    "storeId": "0",
    "value": "330169687"
  },
  {
    "domain": ".bilibili.com",
    "expirationDate": 1771687690.902801,
    "hostOnly": False,
    "httpOnly": False,
    "name": "DedeUserID__ckMd5",
    "path": "/",
    "sameSite": "no_restriction",
    "secure": True,
    "session": False,
    "storeId": "0",
    "value": "5d3ddc339c86c70b"
  },
  {
    "domain": ".bilibili.com",
    "expirationDate": 1771687690.902825,
    "hostOnly": False,
    "httpOnly": False,
    "name": "sid",
    "path": "/",
    "sameSite": "unspecified",
    "secure": False,
    "session": False,
    "storeId": "0",
    "value": "q9sv9wkn"
  },
  {
    "domain": ".bilibili.com",
    "hostOnly": False,
    "httpOnly": False,
    "name": "bsource",
    "path": "/",
    "sameSite": "unspecified",
    "secure": False,
    "session": True,
    "storeId": "0",
    "value": "search_bing"
  },
  {
    "domain": ".bilibili.com",
    "expirationDate": 1802654577,
    "hostOnly": False,
    "httpOnly": False,
    "name": "theme-tip-show",
    "path": "/",
    "sameSite": "unspecified",
    "secure": False,
    "session": False,
    "storeId": "0",
    "value": "SHOWED"
  },
  {
    "domain": "www.bilibili.com",
    "hostOnly": True,
    "httpOnly": False,
    "name": "bmg_af_switch",
    "path": "/",
    "sameSite": "unspecified",
    "secure": False,
    "session": True,
    "storeId": "0",
    "value": "1"
  },
  {
    "domain": "www.bilibili.com",
    "hostOnly": True,
    "httpOnly": False,
    "name": "bmg_src_def_domain",
    "path": "/",
    "sameSite": "unspecified",
    "secure": False,
    "session": True,
    "storeId": "0",
    "value": "i0.hdslb.com"
  },
  {
    "domain": ".bilibili.com",
    "hostOnly": False,
    "httpOnly": False,
    "name": "b_lsid",
    "path": "/",
    "sameSite": "unspecified",
    "secure": False,
    "session": True,
    "storeId": "0",
    "value": "E5DC581B_19C5EE4D0E4"
  }
]
    for cookie in cookies:
        browser.set.cookies(cookie)

    # 调用爬取函数
    # url_result_list = [craw(browser, url) for url in url_list]

    # with open('./url_list/url.txt', 'w+', encoding='utf-8') as fw:
    #     fw.write(str(url_result_list))
    #
    # print(url_result_list)

    # 3. 绑定浏览器实例到craw函数（多线程传递公共参数）
    # craw_with_browser = functools.partial(craw, browser)
    # 4. 多线程执行并收集结果
    # url_result_list = []
    # with ThreadPoolExecutor(max_workers=4) as executor:
    #     # map返回迭代器，遍历收集所有返回的URL
    #     results = executor.map(craw_with_browser, url_list)
    #     # 过滤掉爬取失败的None值，得到有效URL列表
    #     url_result_list = [url for url in results if url is not None]

    # ===================== 第二步：多线程打开监听到的URL =====================
    # 读取文件并解析
    with open('./url_list/url.txt', 'r', encoding='utf-8') as f:
        urls_list = ast.literal_eval(f.read().strip())

    if urls_list:  # 仅当有监听到的URL时执行
        with ThreadPoolExecutor(max_workers=4) as executor:
            executor.map(parse, urls_list)
    # print(urls_list)

    # 5. 关闭浏览器实例释放资源
    browser.quit()


