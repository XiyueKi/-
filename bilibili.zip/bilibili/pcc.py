import pandas as pd
from pyecharts.charts import HeatMap, Bar
from pyecharts import options as opts
import os

CSV_PATH = "./out_CSV/bilibili_weekly_all_cleaned.csv"  # 按需改成你的 csv 路径
OUT_HTML = "analysis_combined_smooth.html"


def make_heatmap(df):
    cols = ["播放量", "点赞数", "投币数", "收藏数", "弹幕数", "分享数", "评论数"]
    for col in cols:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    corr_matrix = df[cols].corr().round(2)
    data_heatmap = []
    for i in range(len(cols)):
        for j in range(len(cols)):
            data_heatmap.append([i, j, float(corr_matrix.iloc[i, j])])

    heatmap = (
        HeatMap(init_opts=opts.InitOpts(width="100%", height="600px"))
        .add_xaxis(cols)
        .add_yaxis(
            "相关系数",
            cols,
            data_heatmap,
            label_opts=opts.LabelOpts(is_show=True, position="inside"),
        )
        .set_global_opts(
            title_opts=opts.TitleOpts(title="B站指标相关性分析", pos_left="center"),
            visualmap_opts=opts.VisualMapOpts(
                min_=-1,
                max_=1,
                is_piecewise=False,
                orient="vertical",
                pos_right="5%",
                pos_top="middle"
            ),
        )
    )
    return heatmap

def make_bar(df):
    # 计算互动率
    df['互动总数'] = df['点赞数'].astype(float) + df['投币数'].astype(float) + df['收藏数'].astype(float)
    df['转化率'] = (df['互动总数'] / df['播放量'].replace(0, pd.NA) * 100).fillna(0)

    # 按分区取均值并排序取前10
    cat_engagement = df.groupby('视频分区')['转化率'].mean().reset_index().sort_values('转化率', ascending=False).head(10)

    bar = (
        Bar(init_opts=opts.InitOpts(width="100%", height="600px"))
        .add_xaxis(cat_engagement['视频分区'].tolist())
        .add_yaxis(
            "平均互动转化率 (%)",
            [round(x, 2) for x in cat_engagement['转化率'].tolist()],
            label_opts=opts.LabelOpts(is_show=True, position="top", formatter="{@[1]}%")
        )
        .set_global_opts(
            title_opts=opts.TitleOpts(title="各分区内容质量对比（互动率）", pos_left="center"),
            xaxis_opts=opts.AxisOpts(axislabel_opts=opts.LabelOpts(rotate=30)),
            yaxis_opts=opts.AxisOpts(axislabel_opts=opts.LabelOpts(formatter="{value}%")),
        )
    )
    return bar

def build_combined_html(heat_embed, bar_embed, out_path, transition_ms=600):
    # 简单模板：两个 chart 的 embed 放在两个覆盖的 div 中，通过 class 切换 show 来控制 opacity
    html_tpl = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>热力图 ↔ 互动率 平滑切换</title>
<style>
  body {{ font-family: "Segoe UI", Roboto, "Helvetica Neue", Arial; margin: 12px; }}
  .controls {{ text-align:center; margin-bottom:8px; }}
  .controls button {{
    padding:8px 12px; margin:0 6px; border-radius:6px; border:1px solid #ccc; cursor:pointer;
    background:#fff;
  }}
  .container {{
    position: relative;
    width: 100%;
    max-width: 1200px;
    height: 600px;
    margin: 0 auto;
  }}
  .chart-wrap {{
    position: absolute;
    top: 0; left: 0;
    width: 100%; height: 100%;
    transition: opacity {transition_ms}ms ease;
    opacity: 0;
    pointer-events: none;
  }}
  .chart-wrap.show {{
    opacity: 1;
    pointer-events: auto;
  }}
  /* 给 pyecharts 生成的脚本容器做自适应（若图没有占满） */
  .chart-wrap > div {{ width:100% !important; height:100% !important; }}
</style>
</head>
<body>
  <div class="controls">
    <button id="btn_heat">显示：热力图</button>
    <button id="btn_bar">显示：互动率</button>
  </div>

  <div class="container">
    <div id="wrap_heat" class="chart-wrap show">
      {heat_embed}
    </div>
    <div id="wrap_bar" class="chart-wrap">
      {bar_embed}
    </div>
  </div>

<script>
  // 切换函数：简单切换 show class
  function switchTo(idWrap) {{
    document.querySelectorAll('.chart-wrap').forEach(function(el){{ el.classList.remove('show'); }});
    document.getElementById(idWrap).classList.add('show');
  }}
  document.getElementById('btn_heat').addEventListener('click', function(){{ switchTo('wrap_heat'); }});
  document.getElementById('btn_bar').addEventListener('click', function(){{ switchTo('wrap_bar'); }});

  // 可选：用键盘左右键快速切换
  let order = ['wrap_heat','wrap_bar'];
  let idx = 0;
  document.addEventListener('keydown', function(e){{
    if(e.key === 'ArrowRight' || e.key === 'ArrowLeft') {{
      idx = (idx + 1) % order.length;
      switchTo(order[idx]);
    }}
  }});
</script>

</body>
</html>
"""
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html_tpl)
    print(f"生成完成：{out_path}")

def main():
    if not os.path.exists(CSV_PATH):
        print(f"找不到 CSV：{CSV_PATH}，请检查路径或修改 CSV_PATH。")
        return

    df = pd.read_csv(CSV_PATH, encoding="utf-8-sig")
    heat = make_heatmap(df)
    bar = make_bar(df)

    # render_embed 返回带 <div> 和 <script> 的片段，可以直接嵌入自定义模板
    heat_embed = heat.render_embed()
    bar_embed = bar.render_embed()

    build_combined_html(heat_embed, bar_embed, OUT_HTML, transition_ms=600)
    print("打开生成的 HTML（analysis_combined_smooth.html）即可查看平滑切换效果。")


if __name__ == "__main__":
    main()
